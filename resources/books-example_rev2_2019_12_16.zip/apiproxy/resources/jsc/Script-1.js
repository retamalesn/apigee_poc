 print(context.getVariable("queryinfo.criteriaValue"));
 print(context.getVariable("queryinfo.actualValue"));