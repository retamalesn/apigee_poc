var isHit = context.getVariable("responsecache.RC-responseMoviesCache.cachehit");
print("isHit: " + isHit);
context.setVariable("isHit", isHit);