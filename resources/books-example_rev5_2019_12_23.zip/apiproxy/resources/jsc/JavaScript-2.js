print("totalItemsVar: " + context.getVariable("responseInfo.totalItemsVar"));
print("kindVar: " + context.getVariable("responseInfo.kindVar"));
print("id0: " + context.getVariable("responseInfo.id0"));
print("etag0: " + context.getVariable("responseInfo.etag0"));
print("title0: " + context.getVariable("responseInfo.title0"));
print("id1: " + context.getVariable("responseInfo.id1"));
print("etag1: " + context.getVariable("responseInfo.etag1"));
print("title1: " + context.getVariable("responseInfo.title1"));